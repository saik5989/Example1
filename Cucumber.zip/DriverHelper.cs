﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Text;

namespace aheadrace
{
    public class DriverHelper
    {
        public IWebDriver Driver { get; set; }

        public void start()
        {
            Driver = new ChromeDriver(@"C:\Users\swaroop\source\repos\TestProject1-master\chromedriver");

        }
    }
}
