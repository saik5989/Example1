﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace aheadrace.Pages
{
    class LoginPage
    {

        private DriverHelper _driverHelper;
        CustomControl customcontrol;

        public LoginPage(DriverHelper driverHelper)
        {
            this._driverHelper = driverHelper;
            customcontrol = new CustomControl(driverHelper);
            
        }

        IWebElement txtsoapEndpoint => _driverHelper.Driver.FindElement(By.Id("soapEndpoint"));
        IWebElement txtrestEndpoint => _driverHelper.Driver.FindElement(By.Id("restEndpoint"));
        IWebElement txtendpoint => _driverHelper.Driver.FindElement(By.Id("endpoint"));

        IWebElement txtinitialBalance => _driverHelper.Driver.FindElement(By.Id("initialBalance"));
        IWebElement txtminimumBalance => _driverHelper.Driver.FindElement(By.Id("minimumBalance"));
        IWebElement txtloanProvider => _driverHelper.Driver.FindElement(By.Id("loanProvider"));

        IWebElement txtloanProcessor => _driverHelper.Driver.FindElement(By.Id("loanProcessor"));

        IWebElement txtloanProcessorThreshold => _driverHelper.Driver.FindElement(By.Id("loanProcessorThreshold"));
        IWebElement btnsubmit => _driverHelper.Driver.FindElement(By.XPath("//input[@value='Submit']"));


        public void EnterAdministration(string soap, string rest, string end, string inbal, string min, string lprcc,string thold,  string lprv)
        {
            txtsoapEndpoint.SendKeys(soap);
            txtrestEndpoint.SendKeys(rest);
            txtendpoint.SendKeys(inbal);
            txtinitialBalance.SendKeys(end);
            txtminimumBalance.SendKeys(min);
            txtloanProcessor.SendKeys(lprcc);
            txtloanProvider.SendKeys(lprv);
            txtloanProcessorThreshold.SendKeys(thold);
        }

        public void ClickSubmit()
        {
            btnsubmit.Click();
        }

    }
}

