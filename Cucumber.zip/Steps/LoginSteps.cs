﻿using aheadrace.Pages;
using NPOI.SS.Formula.Functions;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace aheadrace.Steps
{
    [Binding]
    public  class LoginSteps
    {
        private IWebDriver Driver;
        LoginPage loginpage;
        RequestNewPassword reqnewpass;
        UsersPage userspage;
        private DriverHelper _driverHelper;
        CustomControl customcontrol;

        public LoginSteps(DriverHelper driverHelper)
        {
            _driverHelper = driverHelper;
            customcontrol = new CustomControl(driverHelper);    
            loginpage = new LoginPage(driverHelper);
            reqnewpass = new RequestNewPassword(driverHelper);
            userspage = new UsersPage(driverHelper);
           
        }


        [Given(@"I navigate to application\.")]
        public void GivenINavigateToApplication_()
        {
            _driverHelper.Driver.Navigate().GoToUrl("https://parabank.parasoft.com/parabank/admin.htm");
            customcontrol.Maximize();
            customcontrol.WaitForPageLoad(5000);
        }

        [When(@"I enter data\.")]
        public void WhenIEnterUsernameAndPassword_(Table table)
        {
            dynamic data = table.CreateDynamicInstance();
          //  loginpage.EnterAdministration(data.soap, data.rest, data.end, data.inbal, data.min, data.lprcc, data.thold, data.lprv);
            loginpage.EnterAdministration("trw","tr","trt","ter", "sf", "asdf", "sd", "cvcx");

        }

        [When(@"I click on Submit\.")]
        public void WhenIClickOnLogin_()
        {
            loginpage.ClickSubmit();
            Thread.Sleep(1000);
        }

       
    }
}
